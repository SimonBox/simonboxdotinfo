#
# The raw data in the 'raw' directory were downloaded from the Qstarz GPS
# loggers (BT-Q1000X) with the following command:
#  gpsbabel -t -w -i mtk -f /dev/ttyACM0 -o gpx -F X.gpx && mv data.bin X.bin
# where X denotes the label of the logger. GPSBabel version is 1.4.2.
#
# The bin files were then converted to CSV with:
#  find *.gpx | sed 's/.gpx//' | xargs -L1 -I X gpsbabel -t -i mtk-bin -f X.bin -o unicsv -F X_tracks.csv
#  find *.gpx | sed 's/.gpx//' | xargs -L1 -I X gpsbabel -w -i mtk-bin -f X.bin -o unicsv -F X_waypoints.csv
#
# GPX files generated with gpsbabel on Windows were also received from JH;
# these are in the from_JH folder for reference. It was noted that
# from_JH/AH08.gpx differed significantly from the AH08.gpx downloaded as
# above; this may indicate labelling issues, so data files from both sources
# have been kept.
#
# The loggers JRS09, AH09 and AH10 had no data on them (probably because they
# weren't used). JRS07 was not used during the trial; it contains data
# from another period, so it is being ignored. The corresponding .bin files have
# been retained, but the files generated from them have been deleted. The logger
# AH07 is missing; no data was recovered from AH07. One other anomaly: all data
# on JRS03 was recorded twice; I have deleted the duplicate records from the
# track and waypoint csv files but not the GPX. And another anomaly: JRS10's
# Bluetooth was never picked up after 11:45:32 UTC; maybe its Bluetooth stopped
# working, or maybe someone put it somewhere that we could not detect it; we
# have it for nearly all of test 1, so I am leaving it in.
#
# Data from the six Bluetooth detectors are in the bt_*.bin files. The bt_*.csv
# files were obtained by unpacking them using bluetrax_scan_unpack:
#  ../../bluetrax/bluetrax_scan_unpack --file raw/bt_X.bin >raw/bt_X.csv
# The bt_bbn01_am file was recovered from the detector between tests 2 and 3;
# bt_bbn01 was recovered at the end of the day, and it contains all of the data
# from bt_bbn01_am as well as the data from the afternoon.
#
# The probes.csv file records the mapping between GPS logger labels and
# Bluetooth identifiers. There is mostly a 1:1 mapping between loggers and
# vehicles. The only exception is that JLM01 and JRS04 were switched at 1240
# (between tests 2 and 3) for preliminary analysis of the data on JRS04.
#
# There were two motorcycles (loggers AH08 and JH09). I am told that one of them
# broke down in either test 3 or test 4, but I do not see any evidence of this
# in the GPS traces, so I have left them both in. There was one van (logger
# JRS04 in the morning and JLM01 in the afternoon).
#
# All loggers were set to 1Hz logging, except for AH02, which was mistakenly set
# at 0.1Hz.
# 
# Test start and end times are based on Simon Box's notes:
# *******************************************************
# Test, ST, ET, Count
# 1, 11:28:00, 11:43:00, 314
# 2, 11:46:20, 12:01:20, 354
# 3, 13:01:38, 13:16:38, 328
# 4, 13:39:00, 13:54:00, 386
# 
# Notes: times in BST take one hour off for GMT. Experiment with taking stats
# from 1-2 mins after test start to avoid "starting effects".
# ***************************************************
# (Count refers to the number of vehicles that passed through the junction,
# which was recorded manually using a clicker.)
#

# need to set this, otherwise we lose fractional seconds
options(digits.secs=2)

probes <- read.csv('probes.csv')

#
# Read 'unicsv' output from gpsbabel.
#
read.unicsv <- function(file.name) {
  dat <- read.csv(file.name, row.names='No',
    colClasses=list(Date='character',Time='character'))

  # parse dates
  dat$time <- as.POSIXct(paste(dat$Date, dat$Time),
    format='%Y/%m/%d %H:%M:%OS', tz='UTC')
  dat$Date <- NULL
  dat$Time <- NULL

  dat
}

#
# Helper for tag.probe.data.
#
tag.trace <- function(dates, breaks, tz='UTC') {
  stopifnot(length(breaks) %% 2 == 0)

  tags <- rep(NA, length(dates))
  done <- rep(FALSE, length(dates))
  for (i in 1:(length(breaks)/2)) {
    tag <- breaks[2*i-1]
    date <- as.POSIXct(breaks[2*i], tz=tz)

    match <- !done & dates < date;
    tags[match] <- tag
    done <- done | match
  }
  tags
}

#
# Read all of the unicsv GPS track files into one big table.
#
load.probe.data <- function(probes, data.path='raw') {
  dat <- NULL
  for (i in 1:nrow(probes)) {
    file.name <- file.path(data.path, 
      paste(probes$label[i], '_tracks.csv', sep=''))
    if (file.exists(file.name)) {
      dat.i <- read.unicsv(file.name);
      # not all files have all columns due to configuration differences between
      # the gps loggers; fill the missing columns with NAs; here we rely on the
      # fact that JLM01 is loaded first, because it has all columns
      for (name in setdiff(names(dat), names(dat.i))) {
        dat.i[,name] <- NA
      }
      dat.i$probe <- probes$label[i]
      dat <- rbind(dat, dat.i)
    }
  }
  dat
}

#
# Record which test (if any) each GPS record belongs to, based on its time
# stamp.
#
tag.probe.data <- function(dat.probe) {
  # NB: these are UTC time stamps; BST is 1h ahead at this point
  tags <- c(NA, '2012-05-31 11:28:00',
    'test.1',    '2012-05-31 11:43:00',
    NA,          '2012-05-31 11:46:20',
    'test.2',    '2012-05-31 12:01:20',
    NA,          '2012-05-31 13:01:38',
    'test.3',    '2012-05-31 13:16:38',
    NA,          '2012-05-31 13:39:00',
    'test.4',    '2012-05-31 13:54:00')
  transform(dat.probe, tag=tag.trace(time, tags))
}

#
# Load Bluetooth data from all detectors (the CSV files produced by
# bluetrax_scan_unpack).
#
load.bluetooth.data <- function(file.names=Sys.glob('raw/bt_*.csv'), tz='UTC')
{
  do.call(rbind, lapply(file.names, function(file.name) {
    dat <- read.csv(file.name, colClasses=list(time='character'), na.strings='')
    dat$time <- as.POSIXct(dat$time, format='%Y-%m-%d %H:%M:%OS', tz=tz)

    # record which detector this is, based on the file name
    file.name.rx <- '^.*bt_(.+).csv$'
    stopifnot(grepl(file.name.rx, file.name))
    dat$detector <- sub(file.name.rx, '\\1', file.name)

    # ignore device metadata
    dat$services <- NULL
    dat$major <- NULL
    dat$minor <- NULL
    dat$type <- NULL # inquiry only

    dat
  }))
}

#
# main function
#
clean.data <- function() {
  #
  # gps data
  #
  dat.gps <- load.probe.data(probes)
  dat.gps <- tag.probe.data(dat.gps)

  # only really care about which test it was
  dat.gps$test <- as.numeric(sub('\\w+\\.(.\\d)?', '\\1',
    dat.gps$tag, perl=TRUE))
  dat.gps$tag <- NULL

  # drop everything outside of the actual tests
  dat.gps <- subset(dat.gps, !is.na(test))

  # drop the 'Name' -- not helpful
  dat.gps$Name <- NULL

  # see notes at top of file about swap of JLM01 and JRS04
  dat.gps <- subset(dat.gps,
    (!test %in% c(1,2) | probe != 'JLM01') &
    (!test %in% c(3,4) | probe != 'JRS04'))

  #
  # bluetooth detector data
  #
  dat.bt <- load.bluetooth.data()

  # looks like gs01 was an hour behind UTC
  dat.bt$time[dat.bt$detector == 'gs01'] <-
    dat.bt$time[dat.bt$detector == 'gs01'] + 3600
  
  # tag tests
  dat.bt <- tag.probe.data(dat.bt)

  # only really care about which test it was
  dat.bt$test <- as.numeric(sub('\\w+\\.(.\\d)?', '\\1', dat.bt$tag, perl=TRUE))
  dat.bt$tag <- NULL

  # drop everything outside of the actual tests
  dat.bt <- subset(dat.bt, !is.na(test))

  # easier to use labels rather than bdaddrs; we only want the data for the
  # probes (we picked up quite a few other phones etc -- could look at those,
  # too, at some point)
  dat.bt <- merge(subset(probes, select=c(bdaddr, label)), dat.bt) 
  dat.bt$bdaddr <- NULL
  names(dat.bt)[names(dat.bt) == 'label'] <- 'probe'

  # see notes at top of file about swap of JLM01 and JRS04
  dat.bt <- subset(dat.bt,
    (!test %in% c(1,2) | probe != 'JLM01') &
    (!test %in% c(3,4) | probe != 'JRS04'))

  options(digits.secs=0) # gps timestamps are on whole seconds
  write.csv(dat.gps, file="gps.csv", row.names=FALSE)

  options(digits.secs=2)
  write.csv(dat.bt, file="bluetooth.csv", row.names=FALSE)
}

# to check for data counts:
# aggregate(date ~ test + probe, mira.gps, length) 
# only AH02 looks short

